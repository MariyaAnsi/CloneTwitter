<?php

require 'vendor/autoload.php';
$client = new MongoDB\Client;
$companydb = $client->companydb;
$collection=$comanydb->empcoll;

$insertOneResult = $collection->insertOne(
['name'=>'anis','age'=>'23','skill'=>'php']
);
printf("Inserted %d documents", $insertOneResult->getInsertedCount());
var_dump($insertOneResult->getInsertedId());

?>
