<html>
<head>
<link href="https://fonts.googleapis.com/css2?family=Courgette&display=swap" rel="stylesheet">
<style>
.header{
	overflow: hidden;
	background-color: #f1f1f1;
	padding: 5px 10px;

}
 .w1{
	font-family: 'Courgette', cursive;
	font-size: 20px;
	font-weight: bold;
	}
.header a{
	text-decoration: none;
	font-family: 'Courgette', cursive;
	font-size: 16px;

}
.logo{
float: right;
}

</style>
</head>
<body>
<div class="header">
	<pre>
	<img class="logo" src="clonetweetlogo.png" width="200" height="130">
	<span class="w1">Welcome, <?php echo $userData['username']; ?>&nbsp dear..</span><br>
	<a href="home.php">Home</a>&nbsp; <a href="profile.php?id=<?php echo $_SESSION['user']; ?>">View Profile</a>&nbsp; <a href="userlist.php">View users List</a>&nbsp; <a href='logout.php'>log out</a>
	</pre>
</div>
</body>
</html>