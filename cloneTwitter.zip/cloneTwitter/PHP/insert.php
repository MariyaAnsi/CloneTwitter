<?php

require 'vendor/autoload.php';

$client = new MongoDB\Client;

$database = $client->companydb;

$collection = $database->empcoll;
$result=$collection->find(array(),array('projection'=>array('_id'=>false) ) );
$data = iterator_to_array($result);

?>


<html>
<body>
<table>
<thread>

<tr>
<?php foreach($data[0] as $key=>$value):?>
<th>
<?php echo $key ;?>
</th>

<?php endforeach ;?>
</tr>
</thread>
<tbody>
<?php foreach($data as $entry):?>
<tr>
<?php foreach($entry as $key=>$value):?>
<td>
<?php echo $value ;?>
</td>
<?php endforeach ;?>
</tr>
<?php endforeach ;?>
</tbody>
</table>
</body>
</html>