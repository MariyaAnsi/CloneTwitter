
<?php
/*
*login page
*/

session_start();
require_once('dbconnect.php');

if(isset($_SESSION['user'])) {
	header('Location: home.php');
}

if(isset($_POST['username']) && isset($_POST['password'])) {

	$username = $_POST['username'];
	$password = $_POST['password'];
	$result = $db->users->findOne(array('username'=>$username,'password'=>$password));
	if(!$result){
} else {
	$_SESSION['user'] = $result->_id;
	header('Location : home.php');

}
}


?>


<html>
<head>
<title>Twitter Clone</title>
<link rel="stylesheet" href="indexcss.css">
</head>
<body>

<form method="post" action="index.php">
<div class="container">
	
	<input class="un" align="center" type="text" name="username" placeholder="Enter Username" >
	<input class="pass" align="center"  type="password" name="password" placeholder="Enter Password">
	<input class="subbtn" type="submit" value="Login">
	

</div>
</form>
<a href="register.php">No accout? Register here.</a>

</body>
</html>